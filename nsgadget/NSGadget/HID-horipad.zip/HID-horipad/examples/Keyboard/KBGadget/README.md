# USB Keyboard Gadget

Read characters from UART Rx and write USB HID keyboard reports.

